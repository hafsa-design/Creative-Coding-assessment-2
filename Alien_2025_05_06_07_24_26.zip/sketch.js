function setup() {
  createCanvas(400, 400);
  background(230, 240, 255); // light alien sky
  noLoop();
}

function draw() {
  // Body color
  let green = color(120, 255, 150);

  // Shadow
  noStroke();
  fill(50, 100, 100, 50);
  ellipse(200, 350, 100, 20);

  // Body
  fill(green);
  ellipse(200, 260, 80, 100); // body

  // Head (larger for baby look)
  fill(green);
  ellipse(200, 160, 130, 130); // head

  // Eyes (big and glossy)
  fill(0);
  ellipse(170, 150, 30, 40); // left eye
  ellipse(230, 150, 30, 40); // right eye

  fill(255);
  ellipse(175, 145, 8, 8); // left eye sparkle
  ellipse(235, 145, 8, 8); // right eye sparkle

  // Cheeks
  fill(255, 150, 180, 150);
  ellipse(150, 165, 15, 10);
  ellipse(250, 165, 15, 10);

  // Mouth
  fill(0);
  arc(200, 185, 20, 10, 0, PI); // smiling mouth

  // Antennas
  stroke(green);
  strokeWeight(4);
  line(165, 110, 150, 70);
  line(235, 110, 250, 70);

  noStroke();
  fill(255, 100, 200);
  ellipse(150, 70, 12); // left bulb
  ellipse(250, 70, 12); // right bulb

  // Arms (stubby)
  fill(green);
  ellipse(160, 260, 20, 40); // left
  ellipse(240, 260, 20, 40); // right

  // Feet
  ellipse(180, 310, 20, 15);
  ellipse(220, 310, 20, 15);

  // Label
  fill(50);
  textSize(16);
  textAlign(CENTER);
}


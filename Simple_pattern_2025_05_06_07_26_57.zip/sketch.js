function setup() {
  createCanvas(300, 300);
  background(255);
  rectMode(CENTER);
  noLoop();

  let spacing = 50;

  for (let x = spacing / 2; x < width; x += spacing) {
    for (let y = spacing / 2; y < height; y += spacing) {
      push();
      translate(x, y);
      rotate(random(TWO_PI)); // random rotation

      fill(random(100, 255), random(100, 255), random(100, 255));
      noStroke();
      rect(0, 0, 30, 30); // square

      pop();
    }
  }
}

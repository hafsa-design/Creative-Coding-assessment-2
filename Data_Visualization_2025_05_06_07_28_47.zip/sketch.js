function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}let ages = [10, 20, 20, 30, 40, 50, 60, 60, 70, 80, 90, 100];
let bins = [0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100];
let counts = new Array(bins.length - 1).fill(0);

function setup() {
  createCanvas(400, 400);
  noLoop();
  countAges();
}

function countAges() {
  for (let i = 0; i < ages.length; i++) {
    for (let j = 0; j < bins.length - 1; j++) {
      if (ages[i] >= bins[j] && ages[i] < bins[j + 1]) {
        counts[j]++;
      }
    }
  }
}

function draw() {
  background(255);
  let binWidth = width / bins.length;

  for (let i = 0; i < counts.length; i++) {
    let barHeight = map(counts[i], 0, max(counts), 0, height - 50);
    fill(100, 150, 255);
    rect(i * binWidth, height - barHeight - 20, binWidth, barHeight);
  }

  textSize(16);
  textAlign(CENTER);
  text("Age Distribution Histogram", width / 2, 20);
}

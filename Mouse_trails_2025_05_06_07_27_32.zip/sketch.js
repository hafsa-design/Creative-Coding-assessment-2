let trails = []; // Array to hold trail objects

function setup() {
  createCanvas(600, 400);
  noStroke();
}

function draw() {
  // Create a new trail at the mouse position
  let trail = {
    x: mouseX,
    y: mouseY,
    size: random(30, 70),   // Random size for each trail
    color: color(random(255), random(255), random(255), 150), // Random color with transparency
    alpha: 255, // Starting opacity for the trail
  };
  trails.push(trail);

  // Loop through each trail and display it
  for (let i = trails.length - 1; i >= 0; i--) {
    let t = trails[i];
    
    // Draw the trail with a gradient effect and fading opacity
    fill(t.color);
    ellipse(t.x, t.y, t.size, t.size); // Trail circle

    // Gradually reduce opacity and size for fading effect
    t.alpha -= 3;
    t.size -= 0.3;

    // Remove the trail once it fades out
    if (t.alpha <= 0 || t.size <= 0) {
      trails.splice(i, 1);
    }
  }
}

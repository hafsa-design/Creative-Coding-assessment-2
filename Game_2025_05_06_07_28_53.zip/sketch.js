let playerX = 50, playerY = 500;  // Player starting position
let playerSpeed = 5;  // Speed of running
let playerJumping = false;  // To check if the player is in the air
let playerVelocityY = 0;  // For gravity effect
let gravity = 0.5;  // Gravity effect to pull the player down
let jumpStrength = -12;  // Jump strength
let obstacles = [];  // Array to store obstacles
let score = 0;  // Player's score

function setup() {
    createCanvas(800, 600);  // Create a canvas where the game will be played
}

function draw() {
    background(135, 206, 250);  // Light blue background, like the sky
    
    movePlayer();
    generateObstacles();
    checkCollisions();
    displayScore();
}

function movePlayer() {
    playerX += playerSpeed;  // Keep moving forward

    if (keyIsDown(32) && !playerJumping) {  // Spacebar for jumping
        playerVelocityY = jumpStrength;
        playerJumping = true;
    }

    playerY += playerVelocityY;  // Update vertical position
    playerVelocityY += gravity;  // Apply gravity

    // Check if the player lands on the ground
    if (playerY >= 500) {
        playerY = 500;  // Reset player to ground level
        playerVelocityY = 0;
        playerJumping = false;
    }

    // Draw the player
    fill(255, 0, 0);  // Red color for the player
    ellipse(playerX, playerY, 50, 50);
}

function generateObstacles() {
    if (frameCount % 60 === 0) {  // Create an obstacle every second
        let obstacle = {
            x: width,  // Start at the right edge of the screen
            y: 500,    // Position on the ground
            width: 50,
            height: 50
        };
        obstacles.push(obstacle);  // Add the new obstacle to the array
    }

    // Move obstacles to the left
    for (let i = obstacles.length - 1; i >= 0; i--) {
        obstacles[i].x -= 5;  // Move obstacle left

        // If obstacle is off screen, remove it
        if (obstacles[i].x < 0) {
            obstacles.splice(i, 1);
            score += 1;  // Increase score as player avoids the obstacle
        }

        // Draw obstacles
        fill(0);  // Black color for the obstacle
        rect(obstacles[i].x, obstacles[i].y, obstacles[i].width, obstacles[i].height);
    }
}

function checkCollisions() {
    for (let i = 0; i < obstacles.length; i++) {
        let obstacle = obstacles[i];
        
        // Check for collision with any obstacle
        if (playerX + 25 > obstacle.x && playerX - 25 < obstacle.x + obstacle.width &&
            playerY + 25 > obstacle.y && playerY - 25 < obstacle.y + obstacle.height) {
            // Collision detected
            noLoop();  // Stop the game (or reset, depending on how you want to handle it)
            textSize(32);
            textAlign(CENTER, CENTER);
            fill(255, 0, 0);
            text("GAME OVER!", width / 2, height / 2);
        }
    }
}

function displayScore() {
    fill(0);  // Black color for the score text
    textSize(24);
    textAlign(LEFT, TOP);
    text("Score: " + score, 20, 20);  // Display score at the top left
}

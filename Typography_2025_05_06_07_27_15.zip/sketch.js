let textContent = "Shernii";

function setup() {
  createCanvas(600, 400);
  textAlign(CENTER, CENTER);
  textSize(64);
  noLoop();
}

function draw() {
  // Light Gradient Background
  let c1 = color(255, 255, 255); // Light color
  let c2 = color(240, 240, 240); // Slightly darker
  setGradient(0, 0, width, height, c1, c2, 1); // Gradient function

  // Design: Decorative Circles Around Text
  fill(50, 50, 255, 100); // Semi-transparent blue
  noStroke();
  ellipse(width / 2 - 120, height / 2 - 40, 120, 120); // left circle
  ellipse(width / 2 + 120, height / 2 - 40, 120, 120); // right circle
  ellipse(width / 2, height / 2 + 100, 150, 150); // bottom circle

  // Shadow Effect with Slight Jitter for Text
  fill(0, 0, 0, 150); // Soft black shadow
  textSize(64);
  text(textContent, width / 2 + random(-5, 5), height / 2 + random(-5, 5)); // Random jitter for shadow

  // Main Text: Dark
  fill(0); // Dark text color
  text(textContent, width / 2, height / 2); // Centered text
}

// Gradient Function
function setGradient(x, y, w, h, c1, c2, axis) {
  noFill();
  if (axis === 1) { // Vertical gradient
    for (let i = y; i <= y + h; i++) {
      let inter = map(i, y, y + h, 0, 1);
      let c = lerpColor(c1, c2, inter);
      stroke(c);
      line(x, i, x + w, i);
    }
  } else if (axis === 2) { // Horizontal gradient
    for (let i = x; i <= x + w; i++) {
      let inter = map(i, x, x + w, 0, 1);
      let c = lerpColor(c1, c2, inter);
      stroke(c);
      line(i, y, i, y + h);
    }
  }
}


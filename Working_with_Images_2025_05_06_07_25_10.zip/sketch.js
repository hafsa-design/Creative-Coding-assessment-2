function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}
let img;
let maskGraphics;

function preload() {
  // Load a beautiful nature image (you can replace the link with your own)
  img = loadImage('https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=800&q=80');
}

function setup() {
  createCanvas(600, 600);
  
  // Create a mask graphics to shape the image into a circle
  maskGraphics = createGraphics(width, height);
  maskGraphics.noStroke();
  maskGraphics.fill(255);
  maskGraphics.ellipse(width/2, height/2, 400, 400);
}

function draw() {
  background(255);
  
  // Apply mask to image
  let maskedImg = img.get();
  maskedImg.mask(maskGraphics);

  // Simulate a watercolor effect with blend and filter
  image(maskedImg, 0, 0, width, height);
  push();
  tint(255, 150);  // reduce opacity
  image(maskedImg, random(-2, 2), random(-2, 2), width, height);  // small jitter
  pop();
  
  filter(BLUR, 1); // soft blur for watercolor effect

  // Draw text inside the shape
  fill(20, 70, 40, 180);
  textAlign(CENTER, CENTER);
  textSize(32);
  textStyle(BOLD);
  text("Nature Bliss", width/2, height/2);

  noLoop(); // Draw only once
}

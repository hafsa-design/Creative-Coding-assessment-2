function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}
let petalColor;

function setup() {
  createCanvas(500, 500);
  angleMode(DEGREES);
  petalColor = color(255, 100, 150); // default pinkish
}

function draw() {
  background(240, 240, 255);

  translate(width/2, height/2);

  // Stem
  noStroke();
  fill(50, 180, 100);
  rect(-5, 0, 10, 200);

  // Flower center
  fill(255, 200, 0);
  ellipse(0, 0, 40, 40);

  // Petals
  let numPetals = 6;
  let maxPetalSize = map(mouseY, 0, height, 80, 30); // Petal size changes with mouseY

  fill(petalColor);
  stroke(200, 50, 100);
  strokeWeight(1);

  for (let i = 0; i < numPetals; i++) {
    push();
    rotate(i * 360 / numPetals);
    ellipse(0, -maxPetalSize / 2, 40, maxPetalSize);
    pop();
  }

  // Text hint
  noStroke();
  fill(100, 100, 150);
  textAlign(CENTER);
  textSize(14);
  text("Move mouse up/down to open/close the flower\nClick to change petal color!", 0, 250);
}

function mousePressed() {
  // Change petal color on click
  petalColor = color(random(100, 255), random(50, 200), random(100, 255));
}

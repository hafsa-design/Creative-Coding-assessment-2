function setup() {
  createCanvas(600, 300);
  noLoop();
}

function draw() {
  background(220);

  // Car body
  fill(180, 0, 0); // Dark red
  rect(100, 150, 300, 60, 10); // bottom body
  rect(160, 110, 180, 50, 10); // top cabin

  // Windows
  fill(200, 240, 255);
  rect(170, 115, 70, 40); // front window
  rect(245, 115, 80, 40); // back window

  // Wheels
  fill(50);
  ellipse(150, 220, 50); // front wheel
  ellipse(330, 220, 50); // back wheel

  // Wheel rims
  fill(180);
  ellipse(150, 220, 20);
  ellipse(330, 220, 20);

  // Headlights
  fill(255, 255, 100);
  ellipse(100, 170, 10, 20);

  // Taillights
  fill(255, 50, 50);
  ellipse(400, 170, 10, 20);

  // Text Label
  fill(0);
  textSize(16);
}
